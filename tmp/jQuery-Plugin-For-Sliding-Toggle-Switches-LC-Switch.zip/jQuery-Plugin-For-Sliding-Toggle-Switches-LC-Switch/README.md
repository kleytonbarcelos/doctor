LC Switch
==============

Superlight jQuery plugin improving forms look and functionality. 

Give a modern and flat look to your applications and take advantage of events and public functions. Everything in **just 5KB**, all inclusive!

Requires at least jQuery v1.4.2 and supports all browsers (yes, also old IE, up to version 7)

For **documentation** and usage check:
http://www.lcweb.it/lc-switch



* * *

Copyright (c) Luca Montanari 
